from .ai_settings import AISettings
from .app_settings import AppSettings

ai_settings = AISettings()
app_settings = AppSettings()
