import logging

from .logger import Logger

logger: logging.Logger = Logger().logger
